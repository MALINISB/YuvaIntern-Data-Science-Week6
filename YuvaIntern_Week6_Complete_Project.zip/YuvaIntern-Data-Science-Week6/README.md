# Yuva Internship – Week 6: Model Evaluation & Business Impact

## Project
Beauty & Wellness AI – Customer Personalization and Churn Prediction.

## What is included
- `src/generate_data.py`: creates a reproducible 500-row synthetic customer dataset.
- `src/evaluate_models.py`: trains Logistic Regression and Random Forest, evaluates them, performs stratified 5-fold cross-validation, and saves metrics, confusion matrices, ROC curves, comparison chart, and model files.
- `data/`: generated dataset (created when the pipeline is run if absent).
- `outputs/`: evaluation results and visualizations (created by the pipeline).
- `models/`: saved fitted pipelines.
- `reports/`: final Week 6 report.

## Setup
Python 3.10+ is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## Run
Run from the repository root:

```bash
python src/generate_data.py
python src/evaluate_models.py
```

If running the evaluation script directly and the CSV is absent, it attempts to generate the data automatically. If that import path fails in your environment, run `python src/generate_data.py` first.

## Metrics
Accuracy = overall correct predictions. Precision = proportion of predicted churners who truly churn. Recall = proportion of actual churners identified. F1 = balance between precision and recall. ROC-AUC = ability to rank churners above non-churners across thresholds.

## Important note about results
The Week 5 baseline discussed in the Week 6 report recorded 76% accuracy for both models, with F1-scores of 73.91% (Logistic Regression) and 75% (Random Forest). The code in this repository independently regenerates synthetic data and re-evaluates the models; its exact scores can differ because of the generated sample and train/test split. Do not present synthetic results as results from a real business.

## Business use
Treat model scores as decision-support signals. A business should pilot retention offers with a controlled test, monitor false positives and false negatives, protect customer data, and review performance regularly.
