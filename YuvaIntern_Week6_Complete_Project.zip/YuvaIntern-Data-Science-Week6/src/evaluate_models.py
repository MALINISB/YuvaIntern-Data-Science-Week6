"""Train and evaluate churn models for the Beauty & Wellness project."""
from pathlib import Path
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, confusion_matrix, ConfusionMatrixDisplay,
                             RocCurveDisplay, classification_report)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "beauty_wellness_customers.csv"
OUT = ROOT / "outputs"
MODELS = ROOT / "models"
OUT.mkdir(exist_ok=True); MODELS.mkdir(exist_ok=True)

if not DATA.exists():
    from generate_data import make_dataset
    df = make_dataset()
    df.to_csv(DATA, index=False)
else:
    df = pd.read_csv(DATA)

X = df.drop(columns="churn")
y = df["churn"]
numeric = X.select_dtypes(include=["number"]).columns.tolist()
categorical = X.select_dtypes(exclude=["number"]).columns.tolist()
preprocess = ColumnTransformer([
    ("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                      ("scale", StandardScaler())]), numeric),
    ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical)
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
    "Random Forest": RandomForestClassifier(n_estimators=250, max_depth=6,
                                              min_samples_leaf=3, class_weight="balanced",
                                              random_state=42)
}
rows = []
predictions = {}
for name, estimator in models.items():
    pipe = Pipeline([("preprocess", preprocess), ("model", estimator)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    score = pipe.predict_proba(X_test)[:, 1]
    rows.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1-score": f1_score(y_test, pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, score)
    })
    predictions[name] = (pipe, pred, score)
    joblib.dump(pipe, MODELS / (name.lower().replace(" ", "_") + ".joblib"))
    ConfusionMatrixDisplay.from_predictions(y_test, pred)
    plt.title(f"Confusion Matrix - {name}")
    plt.tight_layout()
    plt.savefig(OUT / f"confusion_matrix_{name.lower().replace(' ', '_')}.png", dpi=160)
    plt.close()

results = pd.DataFrame(rows)
results.to_csv(OUT / "model_metrics.csv", index=False)
with open(OUT / "classification_reports.txt", "w", encoding="utf-8") as f:
    for name, (_, pred, _) in predictions.items():
        f.write(f"--- {name} ---\n")
        f.write(classification_report(y_test, pred, zero_division=0) + "\n")

plt.figure()
for name, (pipe, pred, score) in predictions.items():
    RocCurveDisplay.from_predictions(y_test, score, name=name)
plt.plot([0, 1], [0, 1], linestyle="--")
plt.title("ROC Curves - Churn Models")
plt.tight_layout()
plt.savefig(OUT / "roc_curves.png", dpi=160)
plt.close()

results.set_index("Model")[["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"]].plot(
    kind="bar", ylim=(0, 1), figsize=(10, 6)
)
plt.title("Model Performance Comparison")
plt.ylabel("Score")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig(OUT / "model_comparison.png", dpi=160)
plt.close()

# Five-fold stratified cross-validation on the selected model family.
best_name = results.sort_values(["F1-score", "ROC-AUC"], ascending=False).iloc[0]["Model"]
best_pipe = predictions[best_name][0]
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_result = cross_validate(best_pipe, X_train, y_train, cv=cv,
                           scoring=["accuracy", "precision", "recall", "f1", "roc_auc"])
cv_summary = {k.replace("test_", ""): float(np.mean(v))
              for k, v in cv_result.items() if k.startswith("test_")}
summary = {"selected_model": best_name, "test_metrics": results.to_dict(orient="records"),
           "five_fold_cv_mean": cv_summary, "test_rows": int(len(y_test))}
(OUT / "evaluation_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(results.to_string(index=False))
print(f"\nSelected model by F1 then ROC-AUC: {best_name}")
print(f"Outputs saved in: {OUT}")
