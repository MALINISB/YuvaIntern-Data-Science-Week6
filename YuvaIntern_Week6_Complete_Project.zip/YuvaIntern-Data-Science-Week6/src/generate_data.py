"""Generate a reproducible synthetic Beauty & Wellness customer dataset."""
import numpy as np
import pandas as pd

def make_dataset(n=500, seed=42):
    rng = np.random.default_rng(seed)
    age = rng.integers(18, 61, n)
    visits = rng.integers(1, 13, n)
    spend = np.round(rng.normal(1800, 650, n).clip(300, 5000), 2)
    satisfaction = rng.integers(1, 6, n)
    days_since = rng.integers(1, 121, n)
    discount = rng.integers(0, 2, n)
    category = rng.choice(["Skincare", "Haircare", "Wellness", "Makeup"], n)
    # Higher inactivity and lower satisfaction increase churn probability.
    logit = (-1.0 + 0.025*(days_since-45) - 0.48*(satisfaction-3)
             - 0.10*(visits-5) - 0.00025*(spend-1800) + 0.25*discount)
    prob = 1/(1+np.exp(-logit))
    churn = rng.binomial(1, prob)
    return pd.DataFrame({
        "age": age, "monthly_visits": visits, "average_spend": spend,
        "satisfaction_rating": satisfaction, "days_since_last_visit": days_since,
        "used_discount": discount, "preferred_category": category,
        "churn": churn
    })

if __name__ == "__main__":
    df = make_dataset()
    df.to_csv("data/beauty_wellness_customers.csv", index=False)
    print("Created data/beauty_wellness_customers.csv")
